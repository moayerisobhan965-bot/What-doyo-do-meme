#!/bin/sh
printf '\033c\033]0;%s\a' What Meme
base_path="$(dirname "$(realpath "$0")")"
"$base_path/WhatMeme.x86_64" "$@"
